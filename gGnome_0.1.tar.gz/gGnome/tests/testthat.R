library(testthat)
library(gGnome)

test_check('gGnome')
