#include <Rcpp.h>
#include <unordered_set>
using namespace Rcpp;

// [[Rcpp::export]]
LogicalVector dedup_parallel_vectors(List dots) {
  int n = as<NumericVector>(dots[0]).size();  // Assume all vectors same length
  int m = dots.size();  // Number of input vectors
  
  LogicalVector keep(n, false);
  std::unordered_set<double> seen;

  for (int i = 0; i < n; ++i) {
    bool any_seen = false;
    
    for (int j = 0; j < m; ++j) {
      NumericVector col = dots[j];
      double val = col[i];
      if (seen.count(val)) {
        any_seen = true;
        break;
      }
    }

    if (!any_seen) {
      keep[i] = true;
      for (int j = 0; j < m; ++j) {
        seen.insert(as<NumericVector>(dots[j])[i]);
      }
    }
  }

  return keep;
}